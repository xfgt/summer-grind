//
// Created by twister on 8/16/24.
//

#ifndef REMOVEINVALID_H
#define REMOVEINVALID_H



#include "Company.h"


inline void removeInvalid(std::list<Company*>& xv){

    std::list<Company*> temp;

    for(auto& it : xv){
        if(it->getId() < 0){
            delete it;
            it = nullptr;
        } else{
            temp.push_back(it);
        }
    }
    xv.erase(xv.begin(), xv.end());
    xv = temp;
    temp.erase(temp.begin(), temp.end());

}





#endif //REMOVEINVALID_H
