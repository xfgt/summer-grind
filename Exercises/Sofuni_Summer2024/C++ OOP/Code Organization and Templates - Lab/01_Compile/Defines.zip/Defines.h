//
// Created by twister on 7/17/24.
//

#ifndef DEFINES_H
#define DEFINES_H

    #ifndef DONT_COMPILE_THIS
        #define DONT_COMPILE_THIS
        #define STANDARD_TEMPLATE_LIBRARY namespace std
        #include <iostream>
    #endif


#endif //DEFINES_H
